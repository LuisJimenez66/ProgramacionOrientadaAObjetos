'''
Crear una calculadora:
1.- Dos campos de texto
2.- 4 botones para las operaciones
3.- Mostrar el resultado en alerta
'''

from tkinter import *
from controller import funciones
from model import operaciones
from tkinter import messagebox

class vista:
    
#los puse en estaticos pero estaban normales
    def __init__(self,ventana):
        ventana.geometry("600x600")
        ventana.resizable(False,False)
        ventana.title("CALCULADORA")
        self.interfaz(ventana)

    @staticmethod
    def menuprincipal(ventana):
        barra=Menu(ventana)
        ventana.config(menu=barra)
        OperacionesMenu=Menu(barra,tearoff=0) #0 o 1 tearoff
        barra.add_cascade(label="Operaciones", menu=OperacionesMenu)
        OperacionesMenu.add_command(label="Agregar",command=lambda: vista.interfaz(ventana))
        OperacionesMenu.add_command(label="Consultar",command=lambda: vista.mostar_screen(ventana)) 
        OperacionesMenu.add_command(label="Actualizar",command=lambda: vista.actualizar_screen(ventana)) 
        OperacionesMenu.add_command(label="Eliminar",command=lambda: vista.eliminar_screen(ventana)) 
        OperacionesMenu.add_separator()
        OperacionesMenu.add_command(label="Salir",command=ventana.quit) #destruye todo el programa

    @staticmethod
    def borrar_pantalla(ventana):
        for i in ventana.winfo_children():
            i.destroy()
    




    
    #cadauna interfaz es una funcion
    @staticmethod
    def interfaz(ventana):
        vista.borrar_pantalla(ventana)
        vista.menuprincipal(ventana)

        op1=StringVar()
        op2=StringVar()
        op3=StringVar()

        caja1=Entry(ventana,textvariable=op1,width=5,justify="right")
        caja1.focus()
        caja1.pack(pady=10,anchor="center",side="top")

        caja2=Entry(ventana,textvariable=op2,width=5,justify="right")
        caja2.pack(pady=10,anchor="center",side="top")



        btn1=Button(ventana,text="+",command=lambda:funciones.funcionesc.resultado(op1.get(),op2.get(),"SUMA","+"))
        btn1.pack(pady=5)
        btn2=Button(ventana,text="-",command=lambda:funciones.funcionesc.resultado(op1.get(),op2.get(),"RESTA","-"))
        btn2.pack(pady=5)
        btn3=Button(ventana,text="x",command=lambda:funciones.funcionesc.resultado(op1.get(),op2.get(),"MULTIPLICACION","*"))
        btn3.pack(pady=5)
        btn4=Button(ventana,text="/",command=lambda:funciones.funcionesc.resultado(op1.get(),op2.get(),"DIVISION","/"))
        btn4.pack(pady=5)


        btn5=Button(ventana,text="SALIR",command=ventana.destroy)
        btn5.pack(pady=5) 

    @staticmethod 
    def eliminar_screen(ventana):
        vista.borrar_pantalla(ventana)
        vista.menuprincipal(ventana)
        id=StringVar()
        lbltit=Label(ventana,text=".::Borrar una Operacion::.")
        lbltit.pack(pady=5)
        lblind=Label(ventana,text=".::ID de la operacion: ::.")
        lblind.pack(pady=5)
        cajaid=Entry(ventana,width=5,textvariable=id)
        cajaid.pack(pady=5)
        btneli=Button(ventana,text="Eliminar",command=lambda:funciones.funcionesc.eliminar(id.get()))
        btneli.pack(pady=5)
        btnvol=Button(ventana,text="Volver",command=lambda:vista.interfaz(ventana))
        btnvol.pack(pady=5)

    @staticmethod
    def mostar_screen(ventana):
        vista.borrar_pantalla(ventana)
        vista.menuprincipal(ventana)
        txta=Text(ventana,width=65,height=15)
        enc,res=funciones.funcionesc.mostrar()
        txta.insert("1.0",enc)
        txta.insert("2.0",res)
        txta.pack(pady=10)
        btnvolv=Button(ventana,text="Volver",command=lambda:vista.interfaz(ventana))
        btnvolv.pack()

    @staticmethod
    def actualizar_screen(ventana):
        vista.borrar_pantalla(ventana)
        vista.menuprincipal(ventana)
        id=StringVar()
        lblind=Label(ventana,text="Ingresa el id de la operacion a modificar")
        lblind.pack(pady=5)
        caja1=Entry(ventana,textvariable=id,width=5)
        caja1.pack(pady=5)
        btnenv=Button(ventana,text="Actualizar",command=lambda:funciones.funcionesc.check(id.get(),ventana))
        btnenv.pack()
        
        btnvolv=Button(ventana,text="Volver",command=lambda:vista.interfaz(ventana))
        btnvolv.pack(pady=10)
    
    @staticmethod
    def actualizar_screen2(ventana,respuesta):
        vista.borrar_pantalla(ventana)
        vista.menuprincipal(ventana)

        num1=StringVar()
        num2=StringVar()
        simb=StringVar()
        res=StringVar()

        lbltit=Label(ventana,text="Introduce los nuevos cambios")
        lbltit.pack(pady=5)

        caja1=Entry(ventana,textvariable=num1)
        caja1.insert(0,respuesta[2])
        caja1.pack(pady=5)
        caja2=Entry(ventana,textvariable=num2)
        caja2.insert(0,respuesta[3])
        caja2.pack(pady=5)
        caja3=Entry(ventana,textvariable=simb)
        caja3.insert(0,respuesta[4])
        caja3.pack(pady=5)
        caja4=Entry(ventana,textvariable=res)
        caja4.insert(0,respuesta[5])
        caja4.pack(pady=5)

        def enviar_actualizacion():
            si=operaciones.Operaciones.actualizar(num1.get(),num2.get(),simb.get(),res.get(),respuesta[0])
            if si:
                messagebox.showinfo(message=f"Registro actualizado correctamente")
            else:
                messagebox.showinfo(message=f"No se pudo actualizar el registro")

        btnenv=Button(ventana,text="Actualizar",command=enviar_actualizacion)
        btnenv.pack()
        btnvolv=Button(ventana,text="Volver",command=lambda:vista.interfaz(ventana))
        btnvolv.pack(pady=10)
        



#voy a tener una interfaz para cada CRUD la que se llama interfaz en realidad es interfaz
#una sola clase con cada interfaz (pantallas o ventanas) en un metodo 
