'''
Crear una calculadora:
1.- Dos campos de texto
2.- 4 botones para las operaciones
3.- Mostrar el resultado en alerta 
'''

from tkinter import *
from tkinter import messagebox
from model import operaciones
from view import interfaz



# CONTROL APP O CONTROLLER

class funcionesc:

    @staticmethod
    def resultado(num1,num2,tit,simb):
        
        try:
            num1=float(num1)
            num2=float(num2)
            
            #quitar floats

            if simb=="+":
                sum=num1+num2 
                tit="suma"
            elif simb=="-":
                sum=num1-num2
                tit="resta"
            elif simb=="*":
                sum=num1*num2
                tit="multiplicacion"
            elif simb=="/":
                sum=num1/num2
                tit="division"
            resultado=messagebox.askquestion(title=f"{tit}",message=f"{num1}{simb}{num2}={sum} \n¿Deseas guardar en la base de datos?")
            if resultado=="yes":
                operaciones.Operaciones.insertar(num1,num2,simb,sum)
                messagebox.showinfo(message=f"Registro insertado exitosamente")

        except ZeroDivisionError:
            messagebox.showinfo(message=f"0 no divisor")
        except ValueError:
            messagebox.showinfo(message=f"SOLO VALORES NUMERICOS")

    @staticmethod
    def eliminar(id):
        respuesta=operaciones.Operaciones.eliminar(id)
        if respuesta:
            messagebox.showinfo(message=f"Registro eliminado extosamente")
        else:
            messagebox.showinfo(message=f"Fallo al eliminar")


    @staticmethod
    def mostrar(): 
        respuesta=operaciones.Operaciones.mostrar()
        enc=f"{'ID':<10}{'Fecha':<15}{'N1':<10}{'N2':<10}{'SIMBOLO':<10}{'RESULTADO':<15}\n"
        res=""
        for i in respuesta:
            res=res+f"{i[0]:<10}{i[1]}{i[2]:>7}{i[3]:>9}{i[4]:>10}{i[5]:>15}\n" 
        return enc,res

    
    @staticmethod
    def check(id,ventana): 
        respuesta=operaciones.Operaciones.check(id)
        if respuesta:
            interfaz.vista.actualizar_screen2(ventana,respuesta)
        else:
            messagebox.showinfo(message=f"ID no encontrada")


        
        
        


